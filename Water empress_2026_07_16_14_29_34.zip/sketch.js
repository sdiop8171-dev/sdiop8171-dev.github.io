const questions = [
    {
        question: "How many players are on the field for one team during a soccer match?",
        options: ["8", "9", "10", "11"],
        answer: 3,
        explanation: "A soccer team has 11 players on the field, including the goalkeeper."
    },
    {
        question: "What is the name of the player who guards the goal?",
        options: ["Striker", "Midfielder", "Defender", "Goalkeeper"],
        answer: 3,
        explanation: "The goalkeeper protects the goal and is the only player allowed to use their hands inside the penalty area."
    },
    {
        question: "What do you call it when a team scores?",
        options: ["Foul", "Goal", "Corner", "Throw-in"],
        answer: 1,
        explanation: "A goal is scored when the ball fully crosses the goal line inside the posts."
    },
    {
        question: "What happens when the ball goes out over the sideline?",
        options: ["Penalty kick", "Goal kick", "Throw-in", "Free kick"],
        answer: 2,
        explanation: "A throw-in is awarded when the ball leaves the field over the sideline."
    },
    {
        question: "What is the main aim of soccer?",
        options: ["To pass the ball around", "To score more goals than the other team", "To keep the ball in the air", "To hit the post"],
        answer: 1,
        explanation: "The goal of soccer is to score more goals than the opposing team."
    }
];

const scoreEl = document.getElementById("score");
const questionNumberEl = document.getElementById("question-number");
const questionTitleEl = document.getElementById("question-title");
const questionTextEl = document.getElementById("question-text");
const answersEl = document.getElementById("answers");
const feedbackEl = document.getElementById("feedback");
const nextBtn = document.getElementById("next-btn");
const resultPanel = document.getElementById("result-panel");
const gamePanel = document.getElementById("game-panel");
const resultTextEl = document.getElementById("result-text");
const playAgainBtn = document.getElementById("play-again-btn");

let currentQuestion = 0;
let score = 0;

function renderQuestion() {
    const question = questions[currentQuestion];
    questionTitleEl.textContent = `Question ${currentQuestion + 1}`;
    questionNumberEl.textContent = `${currentQuestion + 1}/${questions.length}`;
    questionTextEl.textContent = question.question;
    answersEl.innerHTML = "";
    feedbackEl.textContent = "";
    feedbackEl.className = "";
    nextBtn.hidden = true;

    question.options.forEach((option, index) => {
        const button = document.createElement("button");
        button.className = "answer-btn";
        button.textContent = option;
        button.addEventListener("click", () => checkAnswer(index));
        answersEl.appendChild(button);
    });
}

function checkAnswer(selectedIndex) {
    const question = questions[currentQuestion];
    const buttons = answersEl.querySelectorAll("button");

    buttons.forEach((button, index) => {
        button.disabled = true;
        if (index === question.answer) {
            button.classList.add("correct");
        }
        if (index === selectedIndex && index !== question.answer) {
            button.classList.add("wrong");
        }
    });

    if (selectedIndex === question.answer) {
        score += 1;
        scoreEl.textContent = score;
        feedbackEl.textContent = `Correct! ${question.explanation}`;
        feedbackEl.className = "success";
    } else {
        feedbackEl.textContent = `Not quite. ${question.explanation}`;
        feedbackEl.className = "error";
    }

    nextBtn.hidden = false;
}

function showResult() {
    gamePanel.hidden = true;
    resultPanel.hidden = false;

    const percent = Math.round((score / questions.length) * 100);
    resultTextEl.textContent = `You scored ${score} out of ${questions.length}. That is ${percent}% — great work!`;
}

nextBtn.addEventListener("click", () => {
    if (currentQuestion < questions.length - 1) {
        currentQuestion += 1;
        renderQuestion();
    } else {
        showResult();
    }
});

playAgainBtn.addEventListener("click", () => {
    currentQuestion = 0;
    score = 0;
    scoreEl.textContent = score;
    gamePanel.hidden = false;
    resultPanel.hidden = true;
    renderQuestion();
});

renderQuestion();
